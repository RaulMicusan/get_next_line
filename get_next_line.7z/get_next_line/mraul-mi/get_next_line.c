/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mraul-mi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/02/05 17:26:42 by mraul-mi          #+#    #+#             */
/*   Updated: 2018/02/06 18:14:35 by mraul-mi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

int		get_next_line(int const fd, char **line)
{
	static char	*string;
	char		*buffer;
	int			i;

	string = ft_strdup("");
	buffer = ft_strdup("");
	while ((i = read(fd, buffer, 1)) > 0)
	{
		buffer[i] = '\0';
		read(-1, string, BUFF_SIZE);
		if (buffer[0] == '\n')
			break ;
		string = ft_strjoin(string, buffer);
	}
	if (i == -1)
		return (-1);
	if (i == 0 && ft_strlen(string) == 0)
		return (0);
	*line = string;
	return (1);
}
