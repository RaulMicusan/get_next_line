/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mraul-mi <mraul-mi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/01/16 13:25:52 by mraul-mi          #+#    #+#             */
/*   Updated: 2018/01/17 17:06:04 by mraul-mi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strdup(const char *s1)
{
	int		size;
	char	*new_str;

	size = ft_strlen(s1) + 1;
	new_str = (char *)malloc(sizeof(char) * size);
	if (new_str == NULL)
		return (NULL);
	ft_strcpy(new_str, s1);
	return (new_str);
}
