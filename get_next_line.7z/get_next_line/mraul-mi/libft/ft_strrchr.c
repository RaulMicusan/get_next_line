/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mraul-mi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/01/16 20:12:47 by mraul-mi          #+#    #+#             */
/*   Updated: 2018/01/16 21:59:48 by mraul-mi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strrchr(const char *s, int c)
{
	char *lc;

	lc = (char *)s + ft_strlen(s);
	while (*lc != c)
	{
		if (lc == s)
			return (NULL);
		lc--;
	}
	return (lc);
}
