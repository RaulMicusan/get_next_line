/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_power.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mraul-mi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/02/05 21:56:04 by mraul-mi          #+#    #+#             */
/*   Updated: 2018/02/05 23:02:15 by mraul-mi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int		ft_power(int number, int power)
{
	if (power == 0)
		return (1);
	else if (power < 0)
		return (0);
	return (number * ft_power(number, power - 1));
}
