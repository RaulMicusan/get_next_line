/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mraul-mi <mraul-mi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/01/16 22:49:24 by mraul-mi          #+#    #+#             */
/*   Updated: 2018/01/16 23:04:37 by mraul-mi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int		ft_atoi(const char *str)
{
	int num;
	int nul;

	num = 0;
	nul = 1;
	while (*str == '\r' || *str == '\n' || *str == '\t' || *str == '\f'
			|| *str == ' ' || *str == '\v')
		str++;
	if (*str == '-')
	{
		str++;
		nul = -1;
	}
	else if (*str == '+')
		str++;
	while (*str >= '0' && *str <= '9' && *str)
	{
		num = (num * 10) + (*str - 48);
		str++;
	}
	return (num * nul);
}
